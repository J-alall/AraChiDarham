
import React from 'react';
import { HeartIcon, LanguageIcon } from './icons'; // Re-using HeartIcon

interface HeaderProps {
  currentLang: 'en' | 'fr';
  onLanguageChange: (lang: 'en' | 'fr') => void;
  t: (key: string, replacements?: Record<string, string | number>) => string; // Translation function
}

const Header: React.FC<HeaderProps> = ({ currentLang, onLanguageChange, t }) => {
  return (
    <header className="bg-gradient-to-r from-emerald-600 to-teal-700 text-white p-4 sm:p-6 shadow-lg">
      <div className="container mx-auto flex flex-col sm:flex-row items-center justify-between">
        <div className="flex items-center space-x-3 mb-3 sm:mb-0">
          <HeartIcon className="w-10 h-10 text-pink-300" filled/>
          <h1 className="text-3xl font-bold tracking-tight">{t('appTitle')}</h1>
        </div>
        <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-4">
          <p className="text-sm text-center sm:text-left text-emerald-100">{t('appTagline')}</p>
          <div className="flex items-center space-x-2 bg-black/20 p-1.5 rounded-md">
            <LanguageIcon className="w-5 h-5 text-emerald-200" />
            <select 
              value={currentLang}
              onChange={(e) => onLanguageChange(e.target.value as 'en' | 'fr')}
              className="bg-transparent text-white text-sm focus:outline-none cursor-pointer appearance-none pr-2"
              aria-label={t('languageLabel')}
            >
              <option value="en" className="text-gray-800">EN</option>
              <option value="fr" className="text-gray-800">FR</option>
            </select>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
