// This component is no longer used directly. 
// Its functionality is integrated into the ConfirmationView in App.tsx.
// Keeping the file to avoid breaking imports if any were missed, but it can be deleted.
const ThankYouModal = () => null;
export default ThankYouModal;