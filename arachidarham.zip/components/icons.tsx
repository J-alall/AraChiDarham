import React from 'react';

export const PlusIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
  </svg>
);

export const MinusIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 12h-15" />
  </svg>
);

export const TrashIcon: React.FC<{ className?: string }> = ({ className = "w-5 h-5" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12.56 0c1.153 0 2.242.078 3.324.214m9.236-1.006A48.62 48.62 0 0 1 12 4.5c-2.291 0-4.516.201-6.676.57m13.352 0c1.003.174 1.96.406 2.868.673m-11.536 0c1.408.239 2.827.427 4.288.56M4.772 5.79A2.25 2.25 0 0 1 7.02 3.75h9.96a2.25 2.25 0 0 1 2.248 2.04Z" />
  </svg>
);

// ShoppingCartIcon might not be needed anymore, but keeping for now.
export const ShoppingCartIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 3h1.386c.51 0 .955.343 1.087.835l.383 1.437M7.5 14.25a3 3 0 0 0-3 3h15.75m-12.75-3h11.218c1.121-2.3 2.1-4.684 2.924-7.138a60.114 60.114 0 0 0-16.536-1.84M7.5 14.25 5.106 5.272M6 20.25a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Zm12.75 0a.75.75 0 1 1-1.5 0 .75.75 0 0 1 1.5 0Z" />
  </svg>
);

export const HeartIcon: React.FC<{ className?: string; filled?: boolean }> = ({ className = "w-6 h-6", filled = false }) => (
  <svg xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill={filled ? "currentColor" : "none"} 
    strokeWidth={filled? 0 : 1.5} 
    stroke="currentColor" 
    className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z" />
  </svg>
);

export const CheckCircleIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75 11.25 15 15 9.75M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z" />
  </svg>
);

export const LanguageIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 21l5.25-11.25L21 21m-9-3h7.5M3 5.621a48.474 48.474 0 016-.371m0 0c1.12 0 2.233.038 3.334.114M9 5.25V3m3.334 2.364C13.18 7.061 14.1 9.65 14.1 12c0 2.35-.92 4.939-2.766 6.379M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export const ShareIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.195.025.39.044.586.06.324.031.654.05.99.05.372 0 .749-.024 1.121-.073a48.01 48.01 0 005.313-2.071M7.217 10.907a2.25 2.25 0 00-2.186 0m2.186 0A2.25 2.25 0 015.031 13.1a2.25 2.25 0 010-2.186m0 2.186c-.195-.025-.39-.044-.586-.06a21.432 21.432 0 00-.99-.05c-.372 0-.749.024-1.121.073a48.01 48.01 0 00-5.313 2.071m9.374-3.649a2.25 2.25 0 100 2.186m0-2.186c.195.025.39.044.586.06.324.031.654.05.99.05.372 0 .749-.024 1.121-.073a48.01 48.01 0 005.313-2.071M16.031 5.031a2.25 2.25 0 100 2.186m0-2.186c.195.025.39.044.586.06.324.031.654.05.99.05.372 0 .749-.024 1.121-.073a48.01 48.01 0 005.313-2.071" />
  </svg>
);

export const ApplePayIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => ( // Simple placeholder
  <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" className={className}>
    <path d="M18.667 15.342c-.006 1.053.473 2.106 1.253 2.859-.04.053-.08.106-.12.16-.626.793-1.4 1.32-2.333 1.573-.993.273-2.053.073-2.986-.427-.8-.393-1.567-.906-2.227-1.546-.66-.633-1.253-1.346-1.727-2.16-.766-1.326-1.173-2.886-1.173-4.466 0-1.02.213-2.033.62-2.98.44-.993 1.08-1.833 1.88-2.486.86-.68 1.866-1.04 2.906-1.06.94-.02 1.88.24 2.694.726.046.033.093.06.133.1.087-.066.18-.126.273-.186.74-.486 1.62-.72 2.513-.686.14.013.273.026.407.053-1.04.646-1.746 1.74-1.8 2.92-.04.92.366 1.82.986 2.473.66.666 1.546 1.086 2.486 1.133l.22.014c.067-.286.1-.58.1-.873a4.04 4.04 0 00-.513-1.946c-.02-.06-.046-.113-.073-.166-.753-.873-1.92-1.4-3.14-1.34-1.24.06-2.313.733-2.906 1.74-.533.9-.76 1.953-.687 3.006zM17.067 5.2c.16-.66.08-1.34-.233-1.94-.06.013-.12.02-.18.02-.793 0-1.56-.247-2.206-.687-.6-.406-1.114-.94-1.487-1.573-.326-.04-.66-.06-.993-.06-.98 0-1.913.28-2.68.78-.78.506-1.386 1.2-1.76 2.013-.36.78-.494 1.646-.36 2.486.133.854.526 1.647 1.12 2.294.66.706 1.486 1.2 2.386 1.426.96.24 1.953.187 2.853-.14.88-.32 1.647-.906 2.213-1.68.087-.113.16-.233.227-.353.006-.026.013-.053.013-.08.014-.146.014-.293.014-.44-.007-.906-.3-1.766-.82-2.48z" />
  </svg>
);

export const CreditCardIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 21.75z" />
  </svg>
);

// Generic placeholder for CMI/Wafacash - can be improved with specific logos if available
export const WalletIcon: React.FC<{ className?: string }> = ({ className = "w-6 h-6" }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M21 12a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 12m18 0v6.75A2.25 2.25 0 0118.75 21H5.25A2.25 2.25 0 013 18.75V12m18 0v-6A2.25 2.25 0 0018.75 3.75H5.25A2.25 2.25 0 003 6v6m16.5-3.375V6.75c0-1.036-.84-1.875-1.875-1.875h-1.5c-1.036 0-1.875.84-1.875 1.875v.75" />
    </svg>
);
