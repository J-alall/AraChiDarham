
import React, { useState } from 'react';
import { CURRENCY, DIRECT_DONATION_AMOUNTS } from '../constants';

interface DirectDonationSelectorProps {
  selectedAmount: number;
  onAmountSelect: (amount: number) => void;
  t: (key: string, replacements?: Record<string, string | number>) => string; // Translation function
}

const DirectDonationSelector: React.FC<DirectDonationSelectorProps> = ({ selectedAmount, onAmountSelect, t }) => {
  const [customAmount, setCustomAmount] = useState<string>('');
  const [showCustomInput, setShowCustomInput] = useState<boolean>(false);

  const handlePresetSelect = (amount: number) => {
    setCustomAmount('');
    setShowCustomInput(false);
    onAmountSelect(amount);
  };

  const handleCustomAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setCustomAmount(value);
    const numericValue = parseInt(value, 10);
    if (!isNaN(numericValue) && numericValue > 0) {
      onAmountSelect(numericValue);
    } else if (value === '') {
      onAmountSelect(0); // Clear selection if input is empty
    }
  };

  const handleShowCustomInput = () => {
    setShowCustomInput(true);
    // If custom input is empty when "Other Amount" is clicked, set selected amount to 0
    // to ensure the custom input field is focused visually.
    if (customAmount) {
        const numericValue = parseInt(customAmount, 10);
        if (!isNaN(numericValue) && numericValue > 0) {
            onAmountSelect(numericValue);
        } else {
            onAmountSelect(0);
        }
    } else {
        onAmountSelect(0); // Default to 0 if custom is shown and empty.
    }
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg">
      <h3 className="text-xl font-semibold text-teal-700 mb-4">{t('chooseAmountTitle')}</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mb-4">
        {DIRECT_DONATION_AMOUNTS.map((amount) => (
          <button
            key={amount}
            onClick={() => handlePresetSelect(amount)}
            className={`p-3 border rounded-lg text-center font-medium transition-all duration-200 ease-in-out transform hover:scale-105
              ${selectedAmount === amount && !showCustomInput
                ? 'bg-teal-500 text-white border-teal-500 ring-2 ring-teal-300 shadow-md'
                : 'bg-emerald-50 text-teal-700 hover:bg-teal-100 hover:border-teal-300 border-gray-200'
              }`}
            aria-pressed={selectedAmount === amount && !showCustomInput}
          >
            {amount} {CURRENCY}
          </button>
        ))}
        <button
          onClick={handleShowCustomInput}
          className={`p-3 border rounded-lg text-center font-medium transition-all duration-200 ease-in-out transform hover:scale-105
            ${showCustomInput 
              ? 'bg-teal-500 text-white border-teal-500 ring-2 ring-teal-300 shadow-md' 
              : 'bg-emerald-50 text-teal-700 hover:bg-teal-100 hover:border-teal-300 border-gray-200'
            }`}
          aria-pressed={showCustomInput}
        >
          {t('otherAmountButton')}
        </button>
      </div>
      {showCustomInput && (
        <div className="mt-4">
          <label htmlFor="customAmount" className="block text-sm font-medium text-teal-600 mb-1">
            {t('customAmountLabel')}
          </label>
          <input
            type="number"
            id="customAmount"
            name="customAmount"
            value={customAmount}
            onChange={handleCustomAmountChange}
            placeholder={t('customAmountPlaceholder')}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500 shadow-sm"
            min="1"
            aria-label={`${t('customAmountLabel')} ${CURRENCY}`}
          />
        </div>
      )}
    </div>
  );
};

export default DirectDonationSelector;
