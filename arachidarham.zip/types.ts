export interface GroundingChunkWeb {
  uri: string;
  title: string;
}

export interface GroundingChunk {
  web?: GroundingChunkWeb;
  retrievedContext?: {
    uri: string;
    title: string;
  };
}

// Gift, CartItem, and DonationType have been removed as per the new requirements.
// The application now focuses on direct, anonymous, one-time donations.
