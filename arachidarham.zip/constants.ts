export const CURRENCY = "MAD"; // Moroccan Dirham

export const DIRECT_DONATION_AMOUNTS: number[] = [10, 20, 50, 100]; // New donation amounts

export interface Translations {
  [key: string]: {
    // Header
    appTitle: string;
    appTagline: string;
    languageLabel: string;

    // Creator Story / Landing
    creatorStoryTitle: string;
    creatorStoryP1: string;
    creatorStoryP2: string;
    creatorStoryP3: string;
    creatorStoryP4: string;
    donateCallToAction: string;

    // Amount Selection
    amountSelectionTitle: string;
    amountSelectionSubtitle: string;
    chooseAmountTitle: string;
    otherAmountButton: string;
    customAmountLabel: string;
    customAmountPlaceholder: string;
    proceedToPaymentButton: string;
    selectAmountPrompt: string;

    // Payment View
    paymentTitle: string;
    paymentSubtitle: string;
    choosePaymentMethod: string;
    applePay: string;
    cmi: string;
    wafacash: string;
    card: string;
    recommendedLabel: string;
    payNowButton: string;
    donationSummary: string;
    yourDonation: string;
    selectPaymentPrompt: string;
    simulatedPaymentSecure: string;

    // Confirmation View
    confirmationTitle: string;
    thankYouMessage: string;
    donationReceived: string; // Dynamic part: "Your donation of X MAD has been gratefully received."
    everyContributionHelps: string;
    anonymousMessageLabel: string;
    anonymousMessagePlaceholder: string;
    sendMessageButton: string;
    messageSentConfirmation: string;
    tellFriendButton: string;
    shareMessageSuccess: string;
    shareMessageError: string;
    donateAgainButton: string;
    closeButton: string;

    // Footer
    footerCopyright: string;
    footerCreatedWith: string;
    footerHeart: string;
    footerDemo: string;
    privacyPolicyLink: string; // Placeholder for actual link
    termsOfServiceLink: string; // Placeholder for actual link
  };
}

export const translations: Translations = {
  en: {
    appTitle: "AraChiDarham",
    appTagline: "A simple, anonymous way to offer support.",
    languageLabel: "Language",
    creatorStoryTitle: "A Message from the Creator",
    creatorStoryP1: "Welcome to AraChiDarham.",
    creatorStoryP2: "This little corner of the web exists for a simple reason: sometimes, life throws you a surprise, and a bit of quiet help can go a long way.",
    creatorStoryP3: "No campaigns, no noise — just a simple way to offer support, anonymously and securely.",
    creatorStoryP4: "Every dirham counts, and every gesture is received with gratitude.",
    donateCallToAction: "Make a Donation",
    amountSelectionTitle: "Make a One-Time Donation",
    amountSelectionSubtitle: "Your anonymous support is invaluable. Choose an amount below or enter your own.",
    chooseAmountTitle: "Choose or Enter an Amount",
    otherAmountButton: "Other Amount",
    customAmountLabel: "Enter your amount (MAD):",
    customAmountPlaceholder: "e.g., 75",
    proceedToPaymentButton: "Proceed to Payment",
    selectAmountPrompt: "Please select or enter a donation amount.",
    paymentTitle: "Secure Payment",
    paymentSubtitle: "Complete your anonymous donation.",
    choosePaymentMethod: "Choose a payment method (simulated):",
    applePay: "Apple Pay",
    cmi: "CMI",
    wafacash: "Wafacash",
    card: "Credit/Debit Card",
    recommendedLabel: "(Recommended)",
    payNowButton: "Pay", // Will be dynamic with amount
    donationSummary: "Donation Summary",
    yourDonation: "Your donation:",
    selectPaymentPrompt: "Please select a payment method.",
    simulatedPaymentSecure: "Secure and anonymous payment (simulation).",
    confirmationTitle: "Thank You!",
    thankYouMessage: "Thank you for your generous support!",
    donationReceived: "Your donation of {amount} {currency} has been gratefully received.",
    everyContributionHelps: "Every contribution is precious and makes a real difference.",
    anonymousMessageLabel: "Send an anonymous message of support (optional):",
    anonymousMessagePlaceholder: "Leave a message of encouragement...",
    sendMessageButton: "Send Message",
    messageSentConfirmation: "Your anonymous message has been sent. Thank you!",
    tellFriendButton: "Tell a Friend",
    shareMessageSuccess: "Link copied to clipboard! Thanks for sharing.",
    shareMessageError: "Could not copy link. You can manually share this page.",
    donateAgainButton: "Make Another Donation",
    closeButton: "Close",
    footerCopyright: "AraChiDarham. Created with",
    footerCreatedWith: "AraChiDarham. Created with",
    footerHeart: "♥",
    footerDemo: "This is a demonstration app for direct support. Transactions are simulated.",
    privacyPolicyLink: "Privacy Policy",
    termsOfServiceLink: "Terms of Service",
  },
  fr: {
    appTitle: "AraChiDarham",
    appTagline: "Un moyen simple et anonyme d’apporter du soutien.",
    languageLabel: "Langue",
    creatorStoryTitle: "Un Message du Créateur",
    creatorStoryP1: "Bienvenue sur AraChiDarham.",
    creatorStoryP2: "Ce petit coin du web existe pour une seule raison : parfois, un moment difficile peut être allégé par un petit geste.",
    creatorStoryP3: "Pas de campagne, pas de bruit — juste un moyen simple et anonyme d’apporter du soutien.",
    creatorStoryP4: "Chaque dirham compte, et chaque geste est reçu avec gratitude.",
    donateCallToAction: "Faire un Don",
    amountSelectionTitle: "Faites un don unique",
    amountSelectionSubtitle: "Votre soutien anonyme est précieux. Choisissez un montant ci-dessous ou entrez le vôtre.",
    chooseAmountTitle: "Choisissez ou entrez un montant",
    otherAmountButton: "Autre Montant",
    customAmountLabel: "Entrez votre montant (MAD):",
    customAmountPlaceholder: "Ex: 75",
    proceedToPaymentButton: "Passer au Paiement",
    selectAmountPrompt: "Veuillez sélectionner ou entrer un montant pour votre don.",
    paymentTitle: "Paiement Sécurisé",
    paymentSubtitle: "Finalisez votre don anonyme.",
    choosePaymentMethod: "Choisissez un moyen de paiement (simulé) :",
    applePay: "Apple Pay",
    cmi: "CMI",
    wafacash: "Wafacash",
    card: "Carte de Crédit/Débit",
    recommendedLabel: "(Recommandé)",
    payNowButton: "Payer", // Will be dynamic with amount
    donationSummary: "Récapitulatif du don",
    yourDonation: "Votre don :",
    selectPaymentPrompt: "Veuillez sélectionner un moyen de paiement.",
    simulatedPaymentSecure: "Paiement sécurisé et anonyme (simulation).",
    confirmationTitle: "Merci !",
    thankYouMessage: "Merci pour votre généreux soutien !",
    donationReceived: "Votre don de {amount} {currency} a été reçu avec gratitude.",
    everyContributionHelps: "Chaque contribution est précieuse et fait une réelle différence.",
    anonymousMessageLabel: "Envoyer un message de soutien anonyme (optionnel) :",
    anonymousMessagePlaceholder: "Laissez un message d'encouragement...",
    sendMessageButton: "Envoyer le Message",
    messageSentConfirmation: "Votre message anonyme a été envoyé. Merci !",
    tellFriendButton: "Parler à un Ami",
    shareMessageSuccess: "Lien copié dans le presse-papiers ! Merci de partager.",
    shareMessageError: "Impossible de copier le lien. Vous pouvez partager cette page manuellement.",
    donateAgainButton: "Faire un Autre Don",
    closeButton: "Fermer",
    footerCopyright: "AraChiDarham. Créé avec",
    footerCreatedWith: "AraChiDarham. Créé avec",
    footerHeart: "♥",
    footerDemo: "Ceci est une application de démonstration pour un soutien direct. Les transactions sont simulées.",
    privacyPolicyLink: "Politique de Confidentialité",
    termsOfServiceLink: "Conditions d'Utilisation",
  },
};
