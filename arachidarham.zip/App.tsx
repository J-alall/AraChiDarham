
import React, { useState, useCallback, useEffect } from 'react';
import Header from './components/Header';
import DirectDonationSelector from './components/DirectDonationSelector';
import { CURRENCY, DIRECT_DONATION_AMOUNTS, translations } from './constants';
import { HeartIcon, CheckCircleIcon, ShareIcon, ApplePayIcon, CreditCardIcon, WalletIcon } from './components/icons';

type View = 'landing' | 'amount_selection' | 'payment' | 'confirmation';
type Language = 'en' | 'fr';

// --- Translation Hook ---
const useTranslation = () => {
  const [language, setLanguage] = useState<Language>('fr'); // Default to French

  const setLang = (lang: Language) => {
    setLanguage(lang);
    document.documentElement.lang = lang; // Set lang attribute on HTML element
  };

  const t = useCallback((key: string, replacements?: Record<string, string | number>) => {
    let text = translations[language][key] || translations['en'][key] || key; // Fallback to English then key
    if (replacements) {
      Object.entries(replacements).forEach(([placeholder, value]) => {
        text = text.replace(`{${placeholder}}`, String(value));
      });
    }
    return text;
  }, [language]);

  return { language, setLanguage: setLang, t };
};


// --- Sub-components for Views ---

interface CreatorStoryProps {
  t: (key: string, replacements?: Record<string, string | number>) => string;
  onDonateClick: () => void;
}
const CreatorStoryView: React.FC<CreatorStoryProps> = ({ t, onDonateClick }) => (
  <section id="creator-story" aria-labelledby="creator-story-title" className="mb-10 bg-white p-6 sm:p-8 rounded-xl shadow-xl max-w-2xl mx-auto text-center">
    <HeartIcon className="w-16 h-16 text-pink-400 mx-auto mb-4" filled />
    <h2 id="creator-story-title" className="text-3xl font-bold text-teal-700 mb-6">{t('creatorStoryTitle')}</h2>
    <div className="space-y-4 text-gray-700 text-lg leading-relaxed">
      <p>{t('creatorStoryP1')}</p>
      <p>{t('creatorStoryP2')}</p>
      <p>{t('creatorStoryP3')}</p>
      <p className="font-semibold text-teal-600">{t('creatorStoryP4')}</p>
    </div>
    <button
      onClick={onDonateClick}
      className="mt-8 bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-8 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 transform hover:scale-105 text-lg"
    >
      {t('donateCallToAction')}
    </button>
  </section>
);

interface AmountSelectionViewProps {
  t: (key: string, replacements?: Record<string, string | number>) => string;
  donationAmount: number;
  onAmountSelect: (amount: number) => void;
  onProceed: () => void;
}
const AmountSelectionView: React.FC<AmountSelectionViewProps> = ({ t, donationAmount, onAmountSelect, onProceed }) => (
  <div className="max-w-xl mx-auto bg-white p-6 sm:p-8 rounded-xl shadow-xl">
    <h2 className="text-3xl font-bold text-teal-700 mb-2 text-center">{t('amountSelectionTitle')}</h2>
    <p className="text-gray-600 mb-6 text-center">{t('amountSelectionSubtitle')}</p>
    <DirectDonationSelector
      selectedAmount={donationAmount}
      onAmountSelect={onAmountSelect}
      t={t}
    />
    <button
      onClick={onProceed}
      disabled={donationAmount <= 0}
      className="mt-6 w-full bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-3 px-4 rounded-lg shadow-md hover:shadow-lg transition-colors duration-300 disabled:bg-gray-300 disabled:cursor-not-allowed"
    >
      {t('proceedToPaymentButton')}
    </button>
  </div>
);

interface PaymentViewProps {
  t: (key: string, replacements?: Record<string, string | number>) => string;
  donationAmount: number;
  selectedPaymentMethod: string | null;
  onPaymentMethodSelect: (method: string) => void;
  onPay: () => void;
  isLoading: boolean;
}
const PaymentView: React.FC<PaymentViewProps> = ({ t, donationAmount, selectedPaymentMethod, onPaymentMethodSelect, onPay, isLoading }) => {
  const paymentMethods = [
    { id: 'applepay', name: t('applePay'), icon: <ApplePayIcon className="w-6 h-6 mr-2" />, recommended: true },
    { id: 'cmi', name: t('cmi'), icon: <WalletIcon className="w-6 h-6 mr-2 text-blue-500" /> },
    { id: 'wafacash', name: t('wafacash'), icon: <WalletIcon className="w-6 h-6 mr-2 text-red-500" /> },
    { id: 'card', name: t('card'), icon: <CreditCardIcon className="w-6 h-6 mr-2" /> },
  ];

  return (
    <div className="max-w-xl mx-auto bg-white p-6 sm:p-8 rounded-xl shadow-xl">
      <h2 className="text-3xl font-bold text-teal-700 mb-2 text-center">{t('paymentTitle')}</h2>
      <p className="text-gray-600 mb-6 text-center">{t('paymentSubtitle')}</p>
      
      <div className="bg-emerald-50 p-4 rounded-lg mb-6">
        <h3 className="text-lg font-semibold text-teal-700 mb-2">{t('donationSummary')}</h3>
        <div className="flex justify-between items-center text-xl font-semibold text-gray-800">
            <span>{t('yourDonation')}</span>
            <span>{donationAmount} {CURRENCY}</span>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="text-md font-semibold text-teal-700 mb-3">{t('choosePaymentMethod')}</h4>
        <div className="space-y-3">
          {paymentMethods.map(method => (
            <button
              key={method.id}
              onClick={() => onPaymentMethodSelect(method.id)}
              className={`w-full flex items-center justify-start p-4 border rounded-lg text-left font-medium transition-all duration-200 ease-in-out transform hover:scale-102
                ${selectedPaymentMethod === method.id
                  ? 'bg-teal-500 text-white border-teal-500 ring-2 ring-teal-300 shadow-md'
                  : 'bg-gray-50 text-gray-700 hover:bg-teal-100 hover:border-teal-300 border-gray-200'
                }
                ${method.recommended ? 'border-2 !border-teal-600' : ''} 
              `}
              aria-pressed={selectedPaymentMethod === method.id}
            >
              {method.icon}
              <span className="flex-grow">{method.name}</span>
              {method.recommended && <span className="ml-2 text-xs font-normal px-2 py-0.5 bg-teal-100 text-teal-700 rounded-full">{t('recommendedLabel')}</span>}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={onPay}
        disabled={!selectedPaymentMethod || isLoading}
        className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg shadow-md hover:shadow-lg transition-colors duration-300 disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center text-lg"
      >
        {isLoading ? (
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        ) : null}
        {t('payNowButton')} {donationAmount} {CURRENCY}
      </button>
      <p className="text-xs text-gray-500 mt-3 text-center">
        {t('simulatedPaymentSecure')}
      </p>
    </div>
  );
};

interface ConfirmationViewProps {
  t: (key: string, replacements?: Record<string, string | number>) => string;
  donationAmount: number;
  anonymousMessage: string;
  onAnonymousMessageChange: (message: string) => void;
  onSendMessage: () => void; // Placeholder for actual send logic
  messageSent: boolean;
  onDonateAgain: () => void;
}
const ConfirmationView: React.FC<ConfirmationViewProps> = ({ t, donationAmount, anonymousMessage, onAnonymousMessageChange, onSendMessage, messageSent, onDonateAgain }) => {
  const [shareStatus, setShareStatus] = useState('');

  const handleShare = async () => {
    const shareData = {
      title: t('appTitle'),
      text: t('creatorStoryP4'), // A snippet from creator's story
      url: window.location.href,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
        setShareStatus(t('shareMessageSuccess')); // Though navigator.share doesn't confirm success this way
      } else {
        // Fallback for browsers that don't support navigator.share
        navigator.clipboard.writeText(window.location.href);
        setShareStatus(t('shareMessageSuccess')); // Copied to clipboard
      }
    } catch (err) {
      console.error("Share error:", err);
      setShareStatus(t('shareMessageError'));
    }
     setTimeout(() => setShareStatus(''), 3000);
  };

  return (
    <div className="max-w-xl mx-auto bg-white p-6 sm:p-8 rounded-xl shadow-xl text-center">
      <CheckCircleIcon className="w-20 h-20 text-green-500 mx-auto mb-4" />
      <h2 className="text-3xl font-bold text-teal-700 mb-3">{t('confirmationTitle')}</h2>
      <p className="text-gray-700 text-lg mb-2">
        {t('thankYouMessage')}
      </p>
      <p className="text-gray-600 mb-6 text-lg">
        {t('donationReceived', {amount: donationAmount, currency: CURRENCY})}
      </p>
      
      {!messageSent && (
        <div className="my-6 pt-6 border-t border-gray-200">
          <label htmlFor="anonymousMessage" className="block text-md font-medium text-teal-700 mb-2">
            {t('anonymousMessageLabel')}
          </label>
          <textarea
            id="anonymousMessage"
            rows={3}
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-teal-500 focus:border-teal-500 shadow-sm"
            value={anonymousMessage}
            onChange={(e) => onAnonymousMessageChange(e.target.value)}
            placeholder={t('anonymousMessagePlaceholder')}
          />
          <button
            onClick={onSendMessage}
            disabled={!anonymousMessage.trim()}
            className="mt-3 bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-6 rounded-lg shadow-md hover:shadow-lg transition-colors duration-300 disabled:bg-gray-300"
          >
            {t('sendMessageButton')}
          </button>
        </div>
      )}
      {messageSent && (
         <p className="text-green-600 my-4 p-3 bg-green-50 rounded-md">{t('messageSentConfirmation')}</p>
      )}

      <div className="my-6 pt-6 border-t border-gray-200 space-y-3 sm:space-y-0 sm:flex sm:space-x-4 justify-center">
        <button
          onClick={handleShare}
          className="w-full sm:w-auto flex items-center justify-center bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-6 rounded-lg shadow-md hover:shadow-lg transition-colors duration-300"
        >
          <ShareIcon className="w-5 h-5 mr-2" />
          {t('tellFriendButton')}
        </button>
        <button
          onClick={onDonateAgain}
          className="w-full sm:w-auto bg-emerald-500 hover:bg-emerald-600 text-white font-bold py-2 px-6 rounded-lg shadow-md hover:shadow-lg transition-colors duration-300"
        >
          {t('donateAgainButton')}
        </button>
      </div>
      {shareStatus && <p className="text-sm text-gray-500 mt-2">{shareStatus}</p>}
    </div>
  );
};


// --- Main App Component ---
const App: React.FC = () => {
  const { language, setLanguage, t } = useTranslation();
  const [currentView, setCurrentView] = useState<View>('landing');
  const [donationAmount, setDonationAmount] = useState<number>(0);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string | null>(null);
  const [anonymousMessage, setAnonymousMessage] = useState<string>('');
  const [messageSent, setMessageSent] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    // Set a default donation amount when amount selection view is shown if none selected
    if (currentView === 'amount_selection' && donationAmount === 0) {
      setDonationAmount(DIRECT_DONATION_AMOUNTS[1] || 10);
    }
  }, [currentView, donationAmount]);
  
  const resetDonationState = () => {
    setDonationAmount(DIRECT_DONATION_AMOUNTS[1] || 10);
    setSelectedPaymentMethod(null);
    setAnonymousMessage('');
    setMessageSent(false);
    setIsLoading(false);
  };

  const handleDonateClick = () => setCurrentView('amount_selection');
  
  const handleAmountSelected = (amount: number) => setDonationAmount(amount);

  const handleProceedToPayment = () => {
    if (donationAmount <= 0) {
      alert(t('selectAmountPrompt'));
      return;
    }
    setCurrentView('payment');
  };

  const handlePaymentMethodSelect = (method: string) => setSelectedPaymentMethod(method);

  const handlePay = () => {
    if (!selectedPaymentMethod) {
      alert(t('selectPaymentPrompt'));
      return;
    }
    setIsLoading(true);
    console.log('Simulating Payment:', { donationAmount, selectedPaymentMethod, anonymousMessage, language });
    setTimeout(() => {
      setIsLoading(false);
      setCurrentView('confirmation');
    }, 1500);
  };
  
  const handleSendMessage = () => {
    console.log("Anonymous message to send:", anonymousMessage);
    // Here you would typically send the message to a backend
    setMessageSent(true); 
  };

  const handleDonateAgain = () => {
    resetDonationState();
    setCurrentView('amount_selection');
  };
  
  useEffect(() => {
    window.scrollTo(0, 0); // Scroll to top on view change
  }, [currentView]);


  return (
    <div className="min-h-screen flex flex-col bg-emerald-50 text-gray-800">
      <Header currentLang={language} onLanguageChange={setLanguage} t={t} />
      <main className="container mx-auto p-4 md:p-8 flex-grow">
        {currentView === 'landing' && <CreatorStoryView t={t} onDonateClick={handleDonateClick} />}
        {currentView === 'amount_selection' && <AmountSelectionView t={t} donationAmount={donationAmount} onAmountSelect={handleAmountSelected} onProceed={handleProceedToPayment} />}
        {currentView === 'payment' && <PaymentView t={t} donationAmount={donationAmount} selectedPaymentMethod={selectedPaymentMethod} onPaymentMethodSelect={handlePaymentMethodSelect} onPay={handlePay} isLoading={isLoading} />}
        {currentView === 'confirmation' && <ConfirmationView t={t} donationAmount={donationAmount} anonymousMessage={anonymousMessage} onAnonymousMessageChange={setAnonymousMessage} onSendMessage={handleSendMessage} messageSent={messageSent} onDonateAgain={handleDonateAgain} />}
      </main>
      <footer className="bg-teal-800 text-emerald-100 text-center p-6 mt-auto">
        <p>&copy; {new Date().getFullYear()} {t('footerCopyright')} <span className="text-pink-300">{t('footerHeart')}</span>.</p>
        <p className="text-xs mt-1">{t('footerDemo')}</p>
        <div className="mt-2 text-xs">
            <a href="#privacy" onClick={(e) => {e.preventDefault(); alert('Privacy Policy page (simulated)');}} className="underline hover:text-white_alpha_80 mx-2">{t('privacyPolicyLink')}</a>
            <span className="text-emerald-300">|</span>
            <a href="#terms" onClick={(e) => {e.preventDefault(); alert('Terms of Service page (simulated)');}} className="underline hover:text-white_alpha_80 mx-2">{t('termsOfServiceLink')}</a>
        </div>
      </footer>
    </div>
  );
};

export default App;
